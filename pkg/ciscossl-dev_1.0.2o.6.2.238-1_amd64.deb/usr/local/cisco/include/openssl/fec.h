#ifndef HEADER_FEC_DEPRECATE_H
# define HEADER_FEC_DEPRECATE_H
# include <openssl/ec.h>
#endif

