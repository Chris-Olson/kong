#ifndef HEADER_FECDSA_DEPRECATE_H
# define HEADER_FECDSA_DEPRECATE_H
# include <openssl/ecdsa.h>
#endif

