#ifndef HEADER_FECDH_DEPRECATE_H
# define HEADER_FECDH_DEPRECATE_H
# include <openssl/ecdh.h>
#endif

